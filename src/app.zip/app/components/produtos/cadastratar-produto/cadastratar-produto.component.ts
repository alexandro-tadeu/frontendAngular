import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cadastratar-produto',
  templateUrl: './cadastratar-produto.component.html',
  styleUrls: ['./cadastratar-produto.component.css']
})
export class CadastratarProdutoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
